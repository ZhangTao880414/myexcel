#关闭swap
sudo swapoff -a
vim /etc/fstab #注释掉swap的行

#关闭防火墙
sudo ufw disable 

#禁用selinux,有时候没有selinux
sudo setenforce 0
sudo vi /etc/selinux/config
SELINUX=permissive

#开启数据转发
sudo vim /etc/sysctl.conf
net.ipv4.ip_forward = 1  #开启ipv4转发，允许内置路由

#使修改生效
sudo sysctl -p

vi /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1

sysctl -p /etc/sysctl.d/k8s.conf


#安装一些依赖
sudo apt-get install -y apt-transport-https ca-certificates curl software-properties-common lrzsz

#移除自带docker
sudo apt-get autoremove docker.io
sudo apt-get remove docker docker-engine docker-ce docker.io
sudo apt-get remove --purge docker.ce

#添加docker源
curl -fsSL https://mirrors.ustc.edu.cn/docker-ce/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://mirrors.ustc.edu.cn/docker-ce/linux/ubuntu $(lsb_release -cs) stable"
sudo apt-get update

#查看可安装docker版本
sudo apt-cache madison docker-ce

#安装18.0x版本,建议18.06.3~ce~3-0~ubuntu
sudo apt-get install docker-ce=18.06.3~ce~3-0~ubuntu

#配置docker镜像源

sudo mkdir -p /etc/docker
cat <<EOF >>/etc/docker/daemon.json
{
  "registry-mirrors": ["https://docker.mirrors.ustc.edu.cn"],
  "iptables": false,
  "exec-opts": ["native.cgroupdriver=systemd"],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "100m"
  },
  "storage-driver": "overlay2"
}
EOF

#重启docker
systemctl unmask docker.service
systemctl unmask docker.socket
systemctl daemon-reload
systemctl restart docker

apt-get install -y apt-transport-https ca-certificates curl software-properties-common gnupg2


#配置k8s工具apt源

cd /etc/apt/sources.list.d/;touch kubernetes.list
echo "deb hangzhouttps://mirrors.aliyun.com/kubernetes/apt/  kubernetes-xenial main" >>kubernetes.list
curl https://mirrors.aliyun.com/kubernetes/apt/doc/apt-key.gpg | sudo apt-key add - 

apt-get update 
apt-get install -y apt-transport-https ca-certificates curl software-properties-common gnupg2



#下载工具
#sudo apt-get install -y kubelet kubernetes-cni=0.6.0-00 kubeadm kubectl

sudo apt-cache madison kubeadm
sudo apt-cache madison kubelet
sudo apt-cache madison kubectl
sudo apt-cache madison kubernetes-cni

sudo apt-get install -y kubelet=1.15.2-00 
sudo apt-get install -y kubeadm=1.15.2-00 
sudo apt-get install -y kubectl=1.15.2-00
sudo apt-get install -y kubernetes-cni=0.7.5-00 


#下载镜像列表：

sudo docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/kube-apiserver:v1.15.2
sudo docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/kube-controller-manager:v1.15.2
sudo docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/kube-scheduler:v1.15.2
sudo docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/kube-proxy:v1.15.2
sudo docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/pause:3.1
sudo docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/etcd:3.3.10
sudo docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/coredns:1.3.1

sudo docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/kube-apiserver:v1.15.2 k8s.gcr.io/kube-apiserver:v1.15.2
sudo docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/kube-controller-manager:v1.15.2 k8s.gcr.io/kube-controller-manager:v1.15.2
sudo docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/kube-scheduler:v1.15.2 k8s.gcr.io/kube-scheduler:v1.15.2
sudo docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/kube-proxy:v1.15.2 k8s.gcr.io/kube-proxy:v1.15.2
sudo docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/pause:3.1 k8s.gcr.io/pause:3.1
sudo docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/etcd:3.3.10 k8s.gcr.io/etcd:3.3.10
sudo docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/coredns:1.3.1 k8s.gcr.io/coredns:1.3.1

sudo docker pull jmgao1983/flannel:v0.11.0-amd64
sudo docker tag jmgao1983/flannel:v0.11.0-amd64 quay.io/coreos/flannel:v0.11.0-amd64

k8s.gcr.io/kube-apiserver                                                     v1.15.2             34a53be6c9a7        9 months ago        207MB
k8s.gcr.io/kube-scheduler                                                     v1.15.2             88fa9cb27bd2        9 months ago        81.1MB
k8s.gcr.io/kube-controller-manager                                            v1.15.2             9f5df470155d        9 months ago        159MB
k8s.gcr.io/kube-proxy                                                         v1.15.2             167bbf6c9338        9 months ago        82.4MB
k8s.gcr.io/coredns                                                            1.3.1               eb516548c180        16 months ago       40.3MB
k8s.gcr.io/etcd                                                               3.3.10              2c4adeb21b4f        17 months ago       258MB
k8s.gcr.io/pause                                                              3.1                 da86e6ba6ca1
quay.io/coreos/flannel                                                        v0.11.0-amd64       ff281650a721 

docker save 34a53be6c9a7 >/dev/k8s-resource/kube-apiserver.tar
docker save 88fa9cb27bd2 >/dev/k8s-resource/kube-scheduler.tar
docker save 9f5df470155d >/dev/k8s-resource/kube-controller-manager.tar
docker save 167bbf6c9338 >/dev/k8s-resource/kube-proxy.tar
docker save eb516548c180 >/dev/k8s-resource/coredns.tar
docker save 2c4adeb21b4f >/dev/k8s-resource/etcd.tar
docker save da86e6ba6ca1 >/dev/k8s-resource/pause.tar
docker save ff281650a721 >/dev/k8s-resource/flannel.tar

docker load -i /dev/k8s-resource/kube-apiserver.tar
docker load -i /dev/k8s-resource/kube-scheduler.tar
docker load -i /dev/k8s-resource/kube-controller-manager.tar
docker load -i /dev/k8s-resource/kube-proxy.tar
docker load -i /dev/k8s-resource/coredns.tar
docker load -i /dev/k8s-resource/etcd.tar
docker load -i /dev/k8s-resource/pause.tar
docker load -i /dev/k8s-resource/flannel.tar

-----------------------------------

#下载网络镜像
#docker pull quay.io/coreos/flannel:v0.11.0
或者
docker pull jmgao1983/flannel:v0.11.0-amd64
docker tag jmgao1983/flannel:v0.11.0-amd64 quay.io/coreos/flannel:v0.11.0-amd64



#初始化
kubeadm init --kubernetes-version=v1.15.2 --pod-network-cidr=10.244.0.0/16 --apiserver-advertise-address=0.0.0.0

------------------------
#中途报了一个警告，是cgroup的问题，导致pod通讯的问题，可按链接解决一下，未完善
#[WARNING IsDockerSystemdCheck]: detected "cgroupfs" as the Docker cgroup driver. 
#The recommended driver is "systemd". Please follow the guide at https://kubernetes.io/docs/setup/cri/
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | apt-key add -
add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
apt-get update
apt-get install -y containerd.io=1.2.13-1 
------------------------------------
#如果初始化失败，修复环境
kubeadm reset  #清除 kubeadm init 生成的文件


#配置授权信息
mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config
  
#增加容忍，允许pod在master上运行（只有一台机器，可怜）
kubectl taint nodes --all node-role.kubernetes.io/master-
  
  
#安装Pod Network；kube-flannel.yml中flannel的镜像是0.11.0，quay.io/coreos/flannel:v0.11.0-amd64 ,修改修改哦
mkdir -p ~/k8s/
cd ~/k8s
curl -O https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml
kubectl apply -f  kube-flannel.yml

#查看node
kubectl get nodes


#创建令牌：
kubeadm token create

#node中 执行生成的命令。即可加入集群

  
  
  
  
  
  
  
  
  
  
  